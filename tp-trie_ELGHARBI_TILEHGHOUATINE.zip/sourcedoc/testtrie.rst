======================
:mod:`testtrie` module
======================

.. automodule:: testtrie
   :members:


Affichage d'un trie
-------------------

Voici l'affichage produit par notre programme :

.. _fig:trie1:
.. figure:: images/trie1.png
   :align: center
   :width: 50%
   :alt: exemple de trie

.. _fig:exemple_trie:
.. figure:: images/exempleTrie.png
   :align: center
   :width: 50%
   :alt: exemple trie

