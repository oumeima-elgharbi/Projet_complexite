=========================
:mod:`compacttrie` module
=========================

.. automodule:: compacttrie
   :members:

