-------
tp-trie
-------

~~~~~~~~~~
Etat du TP
~~~~~~~~~~

Nous avons fini le TP.
Tout fonctionne correctement sauf la fonction add du module compactTrie

~~~~~~~~~~~~~~~~~~~~~~
Réponses aux questions
~~~~~~~~~~~~~~~~~~~~~~

~~~~~~~~~~~~~~~~~~~~~~
Construction d’un trie
~~~~~~~~~~~~~~~~~~~~~~

Question 6.1.1
--------------
Réponse : On peut choisir un dictionnaire pour représenter un arbre du module Trie.

Question 6.1.2
--------------
Réponse : On représente le trie de l'exemple par des dictionnaires imbriqués. On marque chaque mot par un marqueur de fin "'_end_'".

{'b': {'a': {'n': {'a': {'n': {'e': {'_end_': '_end_'}}}}}}, 'c': {'i': {'t': {'r': {'o': {'n': {'_end_': '_end_', 'n': {'i': {'e': {'r': {'_end_': '_end_'}}}}}}}}}}, 'p': {'o': {'m': {'m': {'e': {'_end_': '_end_'}}}, 'i': {'r': {'e': {'_end_': '_end_'}}}}}}

Question 6.1.3
--------------
Réponse : Un trie vide est un dictionnaire vide {} ou None.




.. toctree::
   :maxdepth: 1

   trie
   testtrie
   compacttrie
   compacttrietest




