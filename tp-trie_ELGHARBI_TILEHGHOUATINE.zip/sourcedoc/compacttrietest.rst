=============================
:mod:`compacttrietest` module
=============================

.. automodule:: compacttrietest
   :members:


Affichage d'un trie
-------------------

Voici l'affichage produit par notre programme :

Pour un trie compact de grande hauteur, il y un souci au niveau de la fonction ADD, quand il faut éclater un noeud pour en créer deux autres.

.. _fig:trieCompact1:
.. figure:: images/trieCompact1.png
   :align: center
   :width: 50%
   :alt: exemple n°1 de trie compact


.. _fig:trieCompact2:
.. figure:: images/trieCompact2.png
   :align: center
   :width: 50%
   :alt: exemple n°2 de trie compact

.. _fig:exempleCompact:
.. figure:: images/exempleCompact.png
   :align: center
   :width: 50%
   :alt: exemple du trie compact


