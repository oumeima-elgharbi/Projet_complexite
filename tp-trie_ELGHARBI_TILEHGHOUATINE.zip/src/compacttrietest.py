from compacttrie import *

if __name__ == "__main__":
    t = new_trie()
    add(t,"banane")
    add(t,"citronnier")
    add(t,"citron")
    add(t,"pomme")
    add(t,"poire")
    add(t,"ci")
    add(t,"carreau") # itron
    add(t,"car")
    add(t,"carton")
    add(t,"carrelage")
    add(t,"carre")
    print_trie(t)

# ena : # dot -Tpdf -oexempleCompact.pdf exempleCompact.gv
    trieCompact2file(t,"exempleCompact.gv")

    trie1 = new_trie()
    add(trie1,"citronnier")
    add(trie1,"banane")
    add(trie1,"citron")
    add(trie1,"pomme")
    add(trie1,"poire")
    add(trie1,"ci")
    # dot -Tpdf -otrieCompact1.pdf trieCompact1.gv
    trieCompact2file(trie1,"trieCompact1.gv")

#############################"

    trie2 = new_trie()
    add(trie2,"carreau")
    add(trie2,"car")
    add(trie2,"carton")
    add(trie2,"carrelage")
    add(trie2,"carre")
    # dot -Tpdf -otrieCompact2.pdf trieCompact2.gv
    trieCompact2file(trie2,"trieCompact2.gv")
