from trie import *

if __name__ == "__main__":
    t = new_trie()
    add(t,"banane")
    add(t,"citronnier")
    add(t,"citron")
    add(t,"pomme")
    add(t,"poire")
    add(t,"ci")
    
    add(t,"carreau")
    add(t,"car")
    add(t,"carton")
    add(t,"carrelage")
    print_trie(t)
    
# ena : # dot -Tpdf -oexemple.pdf exemple.gv
    trie2file(t,"exemple.gv")

    trie1 = new_trie()
    add(trie1,"banane")
    add(trie1,"citronnier")
    add(trie1,"citron")
    add(trie1,"pomme")
    add(trie1,"poire")
    add(trie1,"ci")
    trie2file(trie1,"trie1.gv")


