# -*- coding: utf-8 -*-

""":mod:`trie` module : 

:author: Oumeima EL GHARBI, Houda TILEHGHOUATINE

:date: 2020, april

"""

def new_trie ():
    """
    Retourne un trie vide
    
    :return: A fresh trie
    :rtype: dict
    """
    return {} 

def is_empty(t):
    """
    Prédicat de vacuité du Trie.
    
    :param t: un trie
    :type t: dict
    :return: True if t is empty, False otherwise
    :rtype: bool
    """
    return t == {} or t == None

_end = '_end_'

def make_Trie (t, w):
    """
    Procédure qui permet l'ajout d'un mot au trie t vide ou contenant la première lettre de w

    :param t: un trie
    :type t: dict
    :param w: un mot à ajouter au trie
    :type w: string
    """
    n = len(w)
    if n != 0:
        current_dict = t
        for letter in w:
            current_dict = current_dict.setdefault(letter, new_trie())
        current_dict[_end] = _end

def add (t,w):
    """
    Ajoute w à un trie t
    
    :param t: un trie
    :type t: dict
    :param w: un mot à ajouter au trie
    :type w: string
    :return: un trie
    :rtype: dict

    :UC: any
    """
    if is_empty(t) and w: # w == True --> w != ''
        make_Trie(t, w)
    else: # Le Trie contient au moins un mot
        if len(w) > 0: # le mot n'est pas vide et le Trie non plus
            first_letter = w[0]
            if not first_letter in t:
                t = t.setdefault(first_letter, new_trie())
                add (t, w[1:])
            else: # la première lettre est dans le dictionnaire                
                make_Trie(t, w)
            
def contains (t,w):
    """
    Vérifie si w appartient au trie t.
    
    :param t: a trie
    :type t: dict
    :param w: un mot
    :type w: string
    :return: True if w is in the trie, False otherwise.
    :rtype: bool

    :UC: any
    
    :Examples:
    >>> t = new_trie()
    >>> add(t, 'pomme')
    >>> add(t, 'poire')
    >>> add(t, 'banane')
    >>> add(t, 'citron')
    >>> contains (t,'poire')
    True
    >>> contains (t,'banane')
    True
    >>> contains (t,'ci')
    False
    >>> contains (t,'poires')
    False
    >>> add(t, 'ci')
    >>> contains (t,'ci')
    True
    >>> d = new_trie()
    >>> add(d, 'résurrectionnelles')
    >>> add(d, 'réimperméabilisons')
    >>> contains (d, 'résurrectionnelles')
    True
    """
    current_dict = t
    for letter in w:
        if letter not in current_dict:
            return False
        current_dict = current_dict[letter]
    return _end in current_dict


global numero
numero = 0

def print_trie (t):
    """
    Imprime au format dot la description du trie, version complète.
    
    :param t: a trie
    :type t: dict
    :return: None

    :Examples:
    >>> t = {'b': {'a': {'n': {'a': {'n': {'e': {'_end_': '_end_'}}}}}}, 'c': {'i': {'t': {'r': {'o': {'n': {'_end_': '_end_', 'n': {'i': {'e': {'r': {'_end_': '_end_'}}}}}}}}}}, 'p': {'o': {'i': {'r': {'e': {'_end_': '_end_'}}}, 'm': {'m': {'e': {'_end_': '_end_'}}}}}}
    >>> print_trie(t)
    digraph G {
    1 [style=filled,color=pink];
    0 -> 1 [label=" b"];
    2 [style=filled,color=pink];
    1 -> 2 [label=" a"];
    3 [style=filled,color=pink];
    2 -> 3 [label=" n"];
    4 [style=filled,color=pink];
    3 -> 4 [label=" a"];
    5 [style=filled,color=pink];
    4 -> 5 [label=" n"];
    6 [style=filled,color=blue];
    5 -> 6 [label=" e"];
    7 [style=filled,color=pink];
    0 -> 7 [label=" c"];
    8 [style=filled,color=pink];
    7 -> 8 [label=" i"];
    9 [style=filled,color=pink];
    8 -> 9 [label=" t"];
    10 [style=filled,color=pink];
    9 -> 10 [label=" r"];
    11 [style=filled,color=pink];
    10 -> 11 [label=" o"];
    12 [style=filled,color=blue];
    11 -> 12 [label=" n"];
    13 [style=filled,color=pink];
    12 -> 13 [label=" n"];
    14 [style=filled,color=pink];
    13 -> 14 [label=" i"];
    15 [style=filled,color=pink];
    14 -> 15 [label=" e"];
    16 [style=filled,color=blue];
    15 -> 16 [label=" r"];
    17 [style=filled,color=pink];
    0 -> 17 [label=" p"];
    18 [style=filled,color=pink];
    17 -> 18 [label=" o"];
    19 [style=filled,color=pink];
    18 -> 19 [label=" i"];
    20 [style=filled,color=pink];
    19 -> 20 [label=" r"];
    21 [style=filled,color=blue];
    20 -> 21 [label=" e"];
    22 [style=filled,color=pink];
    18 -> 22 [label=" m"];
    23 [style=filled,color=pink];
    22 -> 23 [label=" m"];
    24 [style=filled,color=blue];
    23 -> 24 [label=" e"];
    """
    assert type(t) == dict

    global numero
    color = 'pink'
    if not is_empty(t):
        numero_courant = numero
        if numero == 0:
            print("digraph G {")
        for first_letter in t: # pour le parcours dans l'arc
            n = len(t.keys())
            if first_letter != _end:
                next_trie = t[first_letter]
                if  _end in next_trie:
                    color = 'blue'
                else:
                    color = 'pink'
                print("{} [style=filled,color={}];\n".format(numero + 1, color), end=' ')
                print("{} -> {} [label=\" {}\"];\n".format(numero_courant, numero + 1, first_letter), end=' ')
                numero += 1
                print_trie (next_trie) # 'omme' et 'oire'

def print_trie_file (t,fileId):
    """
    Imprime au format dot la description du trie, version qui permet de stocker dans un fichier gv la description du Trie.
    
    :param t: a trie
    :type t: dict
    :param fileId: name of the new file to be made
    :type fileId: string
    """
    assert type(t) == dict
    
    global numero
    color = 'pink'
    if not is_empty(t):
        numero_courant = numero
        for first_letter in t: # pour le parcours dans l'arc
            n = len(t.keys())
            if first_letter != _end:
                next_trie = t[first_letter] 
                if  _end in next_trie:
                    color = 'blue'
                else:
                    color = 'pink'
                print("{} [style=filled,color={}];\n".format(numero + 1, color), end=' ')
                fileId.write("{} [style=filled,color={}];\n".format(numero + 1, color))   
                print("{} -> {} [label=\" {}\"];\n".format(numero_courant, numero + 1, first_letter), end=' ')
                fileId.write("{} -> {} [label=\" {}\"];\n".format(numero_courant, numero + 1, first_letter))

                numero += 1
                print_trie_file (next_trie, fileId)

# Test :
# dot -Tpdf -oexemple.pdf exemple.gv
# dot -Tpdf -otrie1.pdf trie1.gv
# t = {'b': {'a': {'n': {'a': {'n': {'e': {'_end_': '_end_'}}}}}}, 'c': {'i': {'t': {'r': {'o': {'n': {'_end_': '_end_', 'n': {'i': {'e': {'r': {'_end_': '_end_'}}}}}}}}}}, 'p': {'o': {'i': {'r': {'e': {'_end_': '_end_'}}}, 'm': {'m': {'e': {'_end_': '_end_'}}}}}}

    
def trie2file(trie, filename): # cf fonction displayer TP5
    """
    Procédure qui imprime le trie et qui permet la création d'un fichier gv pour avoir ensuite un pdf contenant la représentation du trie

    :param trie: a trie
    :type trie: dict
    :param filename: name of the new file to be made
    :type filename: string
    """
    with open(filename, 'w') as file:
        global numero
        numero = 0
        print("digraph G {\n")
        file.write("digraph G {\n")
        print_trie_file (trie, file)
        print("}\n")
        file.write("}\n")


if __name__ == '__main__':
    import doctest
    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE | doctest.ELLIPSIS, verbose = False)
