# -*- coding: utf-8 -*-

""":mod:`compactTrie` module : 

:author: Oumeima EL GHARBI, Houda TILEHGHOUATINE

:date: 2020, april

"""

def new_trie ():
    """
    Retourne un trie vide

    :return: A fresh trie
    :rtype: dict
    """
    return {}

def is_empty(t):
    """
    Prédicat de vacuité du Trie.
    
    :param t: un trie
    :type t: dict
    :return: True if t is empty, False otherwise
    :rtype: bool
    """
    return t == {} or t == None

_end = '_end_'

def est_prefixe(prefixe, s):
    """
    Prédicat qui retourne True si prefixe est un préfixe de s, False sinon.
    
    :param prefixe: le prefixe
    :type prefixe: string
    :param s: un mot
    :type s: string
    :return: True or False
    :rtype: bool
    
    :Examples:
    >>> est_prefixe('ci', 'citron')
    True
    >>> est_prefixe('cil', 'citron')
    False
    >>> est_prefixe('mes', 'me')
    False
    >>> est_prefixe('bonjour', 'bonjour')
    True
    >>> est_prefixe('tresse', 'pressee')
    False
    >>> est_prefixe('', 'possible')
    True
    """
    if prefixe == '': # cas de base
        return True
    else:
        if len(prefixe) > len(s):
            return False
        if prefixe[0] == s[0]: # le préfixe n'est pas plus long, donc pas de pb d'indexation
            return est_prefixe(prefixe[1:], s[1:])
        else:
            return False
                       
def sans_prefixe(prefixe, s):
    """
    Si 'prefixe' est un préfixe de s, on retourne s sans son préfixe, sinon on retourne s

    :param prefixe: le prefixe
    :type prefixe: string
    :param s: un mot
    :type s: string
    :return: 's' sans 'prefixe' 
    :rtype: string

    :UC: 'prefixe' est un préfixe de s
    
    :Examples:
    >>> sans_prefixe('ci', 'citron')
    'tron'
    
    sans_prefixe('citron', 'ci')
    AssertionError
    sans_prefixe('cil', 'citron')
    AssertionError
    
    >>> sans_prefixe('im', 'impossible')
    'possible'
    >>> sans_prefixe('bonjour', 'bonjour')
    ''
    >>> sans_prefixe('tresse', 'tresser')
    'r'
    """
    assert len(prefixe) <= len(s) and est_prefixe(prefixe, s), "Il faut que {} soit un préfixe de {} !".format(prefixe, s)
    
    if prefixe == '':
        return s 
    else:
        return sans_prefixe (prefixe[1:], s[1:])


def prefixe_commun(s1, s2):
    """
    Retourne les lettres communes entre deux chaines de caractères, sinon la chaine vide

    :param s1: un mot
    :type s1: string
    :param s2: un mot
    :type s2: string
    :return: le prefixe commun entre s1 et s2, sinon la chaine vide
    :rtype: string
    
    :Examples:
    >>> est_prefixe('citron', 'ci')
    False
    >>> prefixe_commun('citron', 'ci')
    'ci'
    >>> prefixe_commun('acide', 'sci')
    ''
    >>> prefixe_commun('poire', 'pomme')
    'po'
    """
    if len(s1) == 0 or len(s2) == 0:
        return ''
    elif s1[0] != s2[0]: # car ref != '' et s != ''
        return ''
    else:
        return s1[0] + prefixe_commun(s1[1:], s2[1:])

def eclater_noeud(t, prefixe, w):
    """
    
    :param t: un trie
    :type t: dict
    :param prefixe: un préfixe de t
    :type prefixe: string
    :param w: un mot à ajouter au trie
    :type w: string
    :return: un trie éclaté où w a été ajouté
    :rtype: dict
    
    """
    # Nous sommes dans le cas de l'ajout de poire à pomme OU de l'ajout de ci à citron
    commun = prefixe_commun(prefixe, w)
    current_dict = t[prefixe]
    mot_1 = sans_prefixe(commun, prefixe) # 'mme'
    mot_2 = sans_prefixe(commun, w)# 'ire'
    x = ''
    
            
    # 1/ Cas pomme et "poire" et 'ci' et 'carreau'
    if mot_2 != '':
        t[commun] = t.pop(prefixe) # prefixe = 'pomme'
        d = t[commun] # dico de 'po' ou de 'c'
        if _end in d:
            d.pop(_end) # on le laisse dans le cas ci et citron
        x1 = d.setdefault(mot_1 + x, new_trie())
        x1[_end] = _end
        x2 = d.setdefault(mot_2, new_trie())
        x2[_end] = _end
    # 2/ Cas citron et "ci"
    else:
        t[w] = {mot_1 : current_dict, '_end_': '_end_'}
        del t[prefixe]
        
    

def add (t,w):
    """
    Ajoute w à un trie t
    https://www.liste-de-mots.com/
    
    :param t: un trie
    :type t: dict
    :param w: un mot à ajouter au trie
    :type w: string
    :return: un trie
    :rtype: dict

    :UC: ...
    """
    n = len(w)
    
    if is_empty(t) and w != '':
        t = t.setdefault(w, new_trie())
        t[_end] = _end
        
    else: # le trie contient au moins un mot
        arc = t.keys() # on a tous les préfixes du tri
        condition = True
        for prefixe in arc: # 'citron'
            commun = prefixe_commun(prefixe, w)
            current_dict = t[prefixe]
            # 1/ Il existe un préfixe parmi la liste des préfixes de t
            #if est_prefixe(prefixe, w): # ajout de 'citronnier' à 'citron'
            if commun == prefixe:
                
                word = sans_prefixe(prefixe, w) # 'nier'
                add (current_dict, word) # # on a trouvé un préfixe parmi l'ensemble des préfixes -- > on descend tant que l'on peut ??
                condition = False
                break
            
        # 2-1/ si mot plus court (ajout de 'ci' à 'citron') ou 'prefixe commun'
            elif commun != '': # on a des lettres communes
                eclater_noeud(t, prefixe, w)    
                condition = False
                break
                
        # 2/ Fin de boucle : On n'a pas de préfixe
        # Sinon, le mot est à ajouter directement dans t  # Le mot n'a pas de préfixe existant dans le Trie (comme 'banane')
        if condition:
            t = t.setdefault(w, new_trie())
            t[_end] = _end 

    
# t = {'banane': {'_end_': '_end_'}, 'po': {'mme': {'_end_': '_end_'}, 'ire': {'_end_': '_end_'}}, 'ci': {'tron': {'_end_': '_end_', 'nier': {'_end_': '_end_'}}, '_end_': '_end_'}}
# prefixe = 'ci'
# w = 'carreau'
# commun = 'c' 
# mot_1 = 'i'
# mot_2 = 'arreau'


def contains (t,w):
    """
    Vérifie si w appartient au Trie Compact t.
    
    :param t: a trie 
    :type t: dict
    :param w: un mot
    :type w: string
    :return: True if w is in the trie, False otherwise.
    :rtype: bool

    :UC: any
    
    :Examples:
    >>> t = new_trie()
    >>> add(t, 'citronnier')
    >>> add(t, 'banane')
    >>> add(t, 'citron')
    >>> add(t, 'pomme')
    >>> add(t, 'poire')
    >>> contains (t,'poire')
    True
    >>> contains (t,'banane')
    True
    >>> contains (t, 'ci')
    False
    >>> contains (t,'poires')
    False
    >>> add(t, 'ci')
    >>> contains (t,'ci')
    True
    >>> contains(t, 'citron')
    True
    >>> contains (t, 'tron')
    False
    >>> contains (t, 'nier')
    False

    >>> d = new_trie()
    >>> add(d, 'résurrectionnelles')
    >>> add(d, 'réimperméabilisons')
    >>> contains (d, 'résurrectionnelles')
    True
    """
    arc = t.keys()
    mot = w
    for prefixe in arc:
        if prefixe == mot:
            return True
        elif est_prefixe(prefixe, mot):
            mot = sans_prefixe(prefixe, mot)
            return contains (t[prefixe], mot)
    return False
    
        

numero = 0

def print_trie (t):
    """
    Imprime au format dot la description du trie, version complète.
    
    :param t: a trie
    :type t: dict
    :return: None
    """
    assert type(t) == dict
    
    global numero
    color = 'pink'
    if not is_empty(t):
        numero_courant = numero
        for first_letter in t: # pour le parcours dans l'arc
            n = len(t.keys())
            if first_letter != _end:
                next_trie = t[first_letter]
                if  _end in next_trie:
                    color = 'blue'
                else:
                    color = 'pink'
                print("{} [style=filled,color={}];\n".format(numero + 1, color), end=' ')
                print("{} -> {} [label=\" {}\"];\n".format(numero_courant, numero + 1, first_letter), end=' ')
                if n == 1:
                    numero_courant = 0
                numero += 1
                print_trie (next_trie)
   

def print_trie_file (t,fileId):
    """
    Imprime au format dot la description du trie, version qui permet de stocker dans un fichier gv la description du Trie.
    
    :param t: a trie
    :type t: dict
    """
    assert type(t) == dict
    
    global numero
    color = 'pink'
    if not is_empty(t):
        numero_courant = numero
        for first_letter in t: # pour le parcours dans l'arc
            n = len(t.keys())
            if first_letter != _end:
                next_trie = t[first_letter] 
                if  _end in next_trie:
                    color = 'blue'
                else:
                    color = 'pink'
                print("{} [style=filled,color={}];\n".format(numero + 1, color), end=' ')
                fileId.write("{} [style=filled,color={}];\n".format(numero + 1, color))   
                print("{} -> {} [label=\" {}\"];\n".format(numero_courant, numero + 1, first_letter), end=' ')
                fileId.write("{} -> {} [label=\" {}\"];\n".format(numero_courant, numero + 1, first_letter))
                if n == 1:
                    numero_courant = 0
                numero += 1
                print_trie_file (next_trie, fileId)

# Test :
# dot -Tpdf -oexempleCompact.pdf exempleCompact.gv
# dot -Tpdf -otrieCompact1.pdf trieCompact1.gv

def trieCompact2file(trie, filename):
    """
    Procédure qui imprime le trie et qui permet la création d'un fichier gv pour avoir ensuite un pdf contenant la représentation du trie

    :param trie: a trie
    :type trie: dict
    :param filename: name of the new file to be made
    :type filename: string
    """
    with open(filename, 'w') as file:
        global numero
        numero = 0
        print("digraph G {\n")
        file.write("digraph G {\n")
        print_trie_file (trie, file)
        print("}\n")
        file.write("}\n")


if __name__ == '__main__':
    import doctest
    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE | doctest.ELLIPSIS, verbose = False)
