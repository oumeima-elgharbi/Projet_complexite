---------------
 tp-bloom
---------------


.. toctree::
   :maxdepth: 1

   bloomfilter.rst

~~~~~~~~~~
Etat du TP
~~~~~~~~~~

Le TP est fini.

~~~~~~~~~~~~~~~~~~~~~~
Réponses aux questions
~~~~~~~~~~~~~~~~~~~~~~

Question 4.2.3
--------------

La taille du filtre pour laquelle un mot tiré au hasard apparaît présent, ce qui veut dire qu’on a un faux positif est pour n = 3 soit :math:`2^3` = 8.


Question 4.3.4
--------------

On constate que, de manière générale, le taux de faux positifs diminue quand la taille du filtre augmente.

On voit aussi sur le graphique que le taux de faux positifs dépend aussi du nombre n de fonctions de hachage utilisées. 
Par exemple, pour n = 1, on a un taux de faux positifs de l'ordre de 60% alors que pour n = 8 fonctions de hachage, le taux est de l'ordre de 99% pour une petite taille de filtre.
Mais, pour une plus grande taille de filtre, si on n'utilise qu'une fonction de hachage, on a un taux de faux positifs plus élevé que si l'on utilise 8 fonctions de hachage.

En conclusion, le taux de faux positifs dépend du nombre de fonctions de hachages et de la taille du filtre utilisé.
Plus la taille du filtre est grande (à partir de :math:`2^12`) et plus le taux de faux positifs diminue ; mais pour une petite taille de filtre (de :math:`2^10` à :math:`2^12`), moins on utilise de fonctions de hachage et moins on aura de faux positifs.


