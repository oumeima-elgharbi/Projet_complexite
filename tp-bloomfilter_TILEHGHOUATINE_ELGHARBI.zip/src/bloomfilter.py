# -*- coding: utf-8 -*-

""":mod:`bloomfilter` module : Implements a bloomfilter.

:author: Houda TILEHGHOUATINE, Oumeima EL GHARBI

:date: 2020, march 18th

"""

def create (n,f,m):
    """
    Creates a new empty Bloom filter of size :math:`2^n`

    :param n: the log of the size of the filter
    :type n: int
    :param f: the hash function who should take as input two 
              parameters: the value to be hashed and the number 
              of the subfunction used
    :type f: function(any,int)
    :param m: the number of functions provided by *f*
    :return: the new Bloom filter
    :rtype: dict
    """
    size = pow(2, n)     
    booleanTab = [False for _ in range(size)] # créer un tableau de booleens / False
    return {'function':f,'tab':booleanTab,'nbFunction':m, 'tabSize': size}

def add (bf, e):
    """
    Adds *e* to *bf*.

    :param bf: A Bloom filter
    :type bf: dict
    :param e: The element to be added
    :type e: Any
    """
    h = bf['function']
    for i in range(1, bf['nbFunction'] + 1): # pour chaque fonction de hachage, qui est en fait une sous-fonction de f
        bf['tab'][h(e, i) % bf['tabSize']] = True
        
def contains (bf, e):
    """
    Returns True if *e* is in *bf*.

    :param bf: A Bloom filter
    :type bf: dict
    :param e: The element to be tested
    :type e: Any
    """
    h = bf['function']
    for i in range(1, bf['nbFunction'] + 1): # pour les m cases de la table B, de 0 à m-1
        if not bf['tab'][h(e, i) % bf['tabSize']]: # s'il n'est pas mis à "True"
            return False
    return True



        
    
