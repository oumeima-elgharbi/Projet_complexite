# -*- coding: utf-8 -*-

""":mod:`test` module : Test module for bloomfilter analysis

:author: Houda TILEHGHOUATINE, Oumeima EL GHARBI

:date: 2020, march 18th

"""
import random
import bloomfilter

nb_hash_functions = 8
random_tab = [ 0 for i in range(128 * nb_hash_functions)]

def init_random_tab ():
    """
    Creates the hash functions.
    """
    global random_tab
    for i in range(128):
        for j in range(nb_hash_functions):
            random_tab[j * 128 + i] = random.randint(1,32000)

def code_of_string (str,n):
    """
    For a given string, returns the hash code for the n-th hashing function.
    
    :param str: The string to be hashed.
    :type str: string
    :param n: The function number.
    :type n: int
    :return: A hash code
    :rtype: int

    .. note:: 
       1 <= n <= nb_hash_functions 
    """
    assert n >= 1, "Le numéro de la fonction n doit être compris entre 1 et le nombre total de fonctions de hachage."
    h = 0
    for character in str: # n = 1 -> 1 ere fct de hachage (0*128+ord(c))
        h += random_tab[(n-1) * 128 + ord(character)] # attention  oublie du *128 au début !!
    return h

def random_word ():
    """
    Returns a word with random letters whose length is between 4 and 7.

    :rtype: string
    """
    letters = [ chr(i) for i in range(ord('a'),ord('z')+1) ] + [ chr(i) for i in range(ord('A'),ord('Z')+1) ]
    length = 4 + random.randint(0,4)
    str = ""
    for i in range(length):
        str = str + random.choice(letters)
    return str

# 4.3. L’analyse des faux-positifs :

def analyse_fp():
    """
    Procédure qui teste l’influence du nombre de fonctions de hachage et de la taille du filtre sur le nombre de faux positifs.
    """
    with open('res.txt', 'w') as file:
        
    # ATTENTION : on teste la présence des mots insérés au hasard et non des 1024 mots du début
        I = [random_word() for _ in range(pow(2,10))] # on a 2**10 mots tirés au hasard à insérer
        cpt_fp, cpt_mots = 0, 0 # compteur de faux positifs, cmpt des mots insérés

        file.write("La taille du filtre, le nombre de fonctions, le nombre de mots testes, le nombre de faux positifs, le taux de faux positifs\n\n")
        for n in range(1, 8 + 1): # nombre de fonctions de hachage
            for t in range(10, 20+1): # log(base 2) de la taille du filtre
                bf = bloomfilter.create(t, code_of_string, n)
                for w in I: # on insère chaque mot dans le bf
                    bloomfilter.add(bf, w)
                for _ in range(pow(2,14) + 1): # + 1 pour avoir 16385 comme dans l'énoncé
                    U = random_word()
                    if not U in I:
                        cpt_mots += 1
                        if bloomfilter.contains(bf,U): # U pas dans I mais contenu dans bf
                            cpt_fp += 1
                taux = cpt_fp / cpt_mots
                print(t, n, cpt_mots, cpt_fp, taux)
                file.write('{} {} {} {} {} \n'.format(t, n, cpt_mots, cpt_fp, taux))
                cpt_fp, cpt_mots = 0, 0 # réinitialisation des compteurs
            print('\n\n')
            file.write('\n\n')
    


if __name__ == "__main__":
    init_random_tab() # initialisation de la table
    
    print('Question 4.2')
    for i in range(0, 10): # on remarque que pour 2**0 à 2**3 on a un faux positif
        bf = bloomfilter.create(i,code_of_string,8)
        w = random_word()
        bloomfilter.add(bf,"timoleon")
        if bloomfilter.contains(bf,"timoleon"):
            print("%s est present" % ("timoleon"))
        if bloomfilter.contains(bf,w):
            print("%s est present" % (w))

    print('\n4.3. L’analyse des faux-positifs :', end='\n')
    analyse_fp()
