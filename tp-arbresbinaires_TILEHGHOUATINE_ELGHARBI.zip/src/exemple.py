# -*- coding: utf-8 -*-

""":mod:`exemple` module : 

:author: Oumeima El Gharbi, Houda TILEHGHOUATINE

:date: 2020, march

"""

from tree import *
import displayer

from test import *

if __name__ == "__main__":
  tree = create(1,create(2,empty_tree(),empty_tree()),create(3,empty_tree(),empty_tree()))
  displayer.tree2file(tree,"exemple.gv")

# dot -Tpdf -oarbre3.pdf arbre3.gv

  arbre1 = arbre1()
  displayer.tree2file(arbre1,"arbre1.gv")

  arbre2 = arbre2()
  displayer.tree2file(arbre2,"arbre2.gv")

  arbre3 = arbre3()
  displayer.tree2file(arbre3,"arbre3.gv")

  abr1 = abr1()
  displayer.tree2file(abr1,"abr1.gv")

  abr1_v1 = abr1_v1()
  displayer.tree2file(abr1_v1,"abr1_v1.gv")

  abr2 = abr2()
  displayer.tree2file(abr2,"abr2.gv")

  abr3 = abr3()
  displayer.tree2file(abr3,"abr3.gv")

  abr_myst = construitArbreEntierMysterieux(12,24)
  displayer.tree2file(abr_myst,"abr_myst.gv")

#

# comandline:
# python3 exemple.py && dot -Tpdf -o exemple.pdf exemple.gv
    
