# -*- coding: utf-8 -*-

""":mod:`test` module : 

:author: Houda TILEHGHOUATINE, Oumeima EL GHARBI

:date: 2020, march

"""

from tree import *
import time

# Manipulation d'arbres binaires 

def arbre1 ():
    """
    Arbre Binaire 1

    :return: a tree
    :rtype: dict
    """
    tree = create(12,create(9,empty_tree(),empty_tree()),create(8,empty_tree(),empty_tree()))
    return tree

def arbre2 ():
    """
    Arbre Binaire 2
    
    :return: a tree
    :rtype: dict
    """
    tree = create(12, create(9, empty_tree(), create(5, create(7, empty_tree(), empty_tree()), empty_tree())), empty_tree())
    return tree

def arbre3 ():
    """
    Arbre Binaire 3
    
    :return: a tree
    :rtype: dict
    """
    tree = create(12, create(9, create(1, empty_tree(), empty_tree()), create(5, empty_tree(), empty_tree())), create(8, empty_tree(), create(4, create(7, empty_tree(), empty_tree()), create(6, empty_tree(), empty_tree()))))
    return tree
    
def imprimer (tree):
    """
    Procédure qui affiche les valeurs d’un arbre binaire de manière infixée

    :param tree: The tree
    :type tree: dict or None
    :return: None
    :rtype: None
    """
    if not is_empty(tree):
        left = get_left_son (tree)
        right = get_right_son (tree)
        imprimer (left) # le noeud de gauche est un arbre
        print(tree["value"], end= ' ')
        imprimer (right)

def taille (tree): 
    """
    Compte le nombre total de nœuds (nœuds internes et feuilles) d’un arbre.

    :param tree: The tree
    :type tree: dict or None
    :return: the number of knots of the tree
    :rtype: int
    """
    if is_empty(tree):
        return 0
    else:
        left = get_left_son (tree)
        right = get_right_son (tree)
        return 1 + taille(left) + taille(right)
    
        
def hauteur (tree): 
    """
    Calcule la hauteur d’un arbre donné en paramètre.
    Rappel cours : c’est le nombre de nœuds sur la branche qui va de la racine de tree à la feuille de profondeur maximale

    :param tree: The tree
    :type tree: dict or None
    :return: The height of the tree
    :rtype: int
    """
    if is_empty(tree):
        return -1
    else:
        left = get_left_son (tree)
        right = get_right_son (tree)
        return 1 + max(hauteur(left),hauteur(right))
        
def nbFeuilles (tree):
    """
    Calcule le nombre de feuilles d’un arbre donné en paramètre.

    :param tree: The tree
    :type tree: dict or None
    :return: the total number of leaves of the tree
    :rtype: int
    """
    if is_empty(tree):
        return 0
    elif is_a_leaf(tree):
        return 1
    else:
        left = get_left_son (tree)
        right = get_right_son (tree)
        return nbFeuilles(left) + nbFeuilles(right)

# Comptage d'arbres

def nbArbres (n):
    """
    Calcule à l'aide d'un algorithme récursif le nombre d'arbres que l'on peut construire pour une taille d'arbre n fixée.

    :param n: La taille de l'arbre
    :type n: int
    :return: the total number of trees
    :rtype: int
    """
    if n == 0:
        return 1
    else:
        somme = sum([nbArbres (k) * nbArbres (n-k-1) for k in range(n)])
        return somme

table = [1, 1] # c0 = 1 et c1 = 1
def nbArbresEfficace (n):
    """
    Calcule à l'aide d'un algorithme itératif le nombre d'arbres que l'on peut construire pour une taille d'arbre n fixée.
    On utilise un tableau pour stocker les valeurs des nombres ck avec k≤n.

    :param n: La taille de l'arbre
    :type n: int
    :return: the total number of trees
    :rtype: int
    """
    if n == 0 or n == 1:
        return 1
    else:
        global table
        somme = sum([table[k] * table[n-k-1] for k in range(n)])
        table.append(somme)
        return somme

# Manipulation d'arbres binaires de recherche 

def abr1_v1 ():
    """
    arbre 1: 6, 4, 2, 7, 5, 1
    
    :return: a tree
    :rtype: dict
    """
    tree = create(6, create(4, create(2, create(1, empty_tree(), empty_tree()), empty_tree()), create(5, empty_tree(), empty_tree())), create(7, empty_tree(), empty_tree()))
    return tree

def ajouter (value,tree):
    """
    Ajoute une valeur à un arbre binaire.
    
    :param tree: The tree
    :type tree: dict or None
    :param value: a value to be added
    :type value: int
    :return: a tree
    :rtype: dict
    """
    if is_empty(tree):
        return create(value, empty_tree(), empty_tree())
    else:
        r, left, right = get_root_value(tree), get_left_son (tree), get_right_son (tree)
        if value <= r:
            ag = ajouter(value, left)
            change_left(tree, ag)
            return tree
        else: # on regarde à droite
            ad = ajouter(value, right)
            change_right(tree, ad)
            return tree

def abr1 ():
    """
    arbre 1: 6, 4, 2, 7, 5, 1
    
    :return: a tree
    :rtype: dict
    """
    l = [6, 4, 2, 7, 5, 1]
    tree = empty_tree()
    for i in l:
        tree = ajouter(i, tree)
    return tree

def abr2 ():
    """
    arbre 2: 5, 4, 2, 7, 6, 1
    
    :return: a tree
    :rtype: dict
    """
    l = [5, 4, 2, 7, 6, 1]
    tree = empty_tree()
    for i in l:
        tree = ajouter(i, tree)
    return tree

def abr3 ():
    """
    arbre 3: 7, 1, 4, 5, 6, 2
    
    :return: a tree
    :rtype: dict
    """
    tree = empty_tree()
    l = [7, 1, 4, 5, 6, 2]
    for i in l:
        tree = ajouter(i, tree)
    return tree

cpt = 0
def compare(x,y):
    """
    Fonction de comparaisons qui compte le nombre de comparaisons.
    
    :param x: an element
    :type x: any type that can be compared with < and >
    :param y: an element
    :type y: any type that can be compared with < and >
    :UC: x and y must be of the same type
    """
    global cpt 
    cpt += 1
    return (x > y) - (x < y)

def appartient (value,tree, cmp = compare):
    """
    Prédicat qui teste si une valeur est présente dans l’arbre.
    
    :param tree: The tree
    :type tree: dict or None
    :param value: a value to be added
    :type value: int
    :return: True if value in tree, False otherwise
    :rtype: bool
    """
    if is_empty(tree):
        return False
    else:
        r = get_root_value(tree)
        if cmp(value, r) == 0:
            return True
        else:
            if cmp(value, r) == -1:
                return appartient(value, get_left_son(tree))
            else: # value > r
                return appartient(value, get_right_son(tree))

            
def maxAbr(tree):
    """
    Retourne l'élément maximal d'un arbre binaire de recherche.
    
    :param tree: The tree
    :type tree: dict or None
    :return: the maximal value of the tree 
    :rtype: int
    """
    assert(tree is not None)
    right = get_right_son(tree)
    r = get_root_value (tree)
    if is_empty(right):
        return r    
    else:
        return maxAbr(right)
        
def minAbr(tree):
    """
    Retourne l'élément minimal d'un arbre binaire de recherche.
    
    :param tree: The tree
    :type tree: dict or None
    :return: the minimal value of the tree 
    :rtype: int
    """
    assert(tree is not None)
    r = get_root_value (tree)
    left = get_left_son(tree)
    if is_empty(left):
        return r
    else:
        return minAbr(left)

# Entier mysterieux 

def construitArbreEntierMysterieux(i,j):
    """
    Fonction récursive qui construit l’ABR du jeu contenant les entiers de i à j, les deux paramètres de la fonction.

    :param i: le premier entier de l'intervalle
    :type i: int
    :param j: le dernier entier de l'intervalle
    :type j: int
    :return: a tree
    :rtype: dict
    
    :UC : i < j and j - i >= 2
    """
    n = j - i
    if n == 0:
        return create(i, empty_tree(), empty_tree()) # i == j
    elif n == 1:
        tree = ajouter(i, empty_tree())
        tree = ajouter(j, tree)
        return tree 
    else:
        mediane = (i + j) // 2 # médiane inf si n impair
        ag = construitArbreEntierMysterieux(i, mediane - 1) # ok
        ad = construitArbreEntierMysterieux(mediane + 1, j) # n pair ou impair pareil
        tree = create(mediane, ag, ad)
        return tree
  
def jouer (n):
    """
    Procédure qui permet de faire jouer l’ordinateur à l”entier mystérieux en utilisant un ABR : vous choisissez un nombre et vous le faites deviner à l’ordinateur (sans tricher, bien sûr).

    :param n: nombre à deviner
    :type n: int
    :return: None
    :rtype: None

    :UC: n > 1
    """
    assert n > 1
    reponse = int(input("Choisis un entier entre 1 et " + str(n) + " et je le devinerai ! "))
    assert 1 <= reponse <= n, "Vous n'avez pas respecté les consignes ... Jeu terminé..."
    tree = construitArbreEntierMysterieux(1,n)
    h = hauteur(tree)
    l = ["gagné", "-", "+"]
    nbCoup = 0

    r = -1 # pour entrer dans la boucle
    while r != reponse and nbCoup <= h:
        try:
            r = get_root_value(tree)
        except AssertionError:
                print("N'aurais-tu pas triché par hasard ? Le jeu est terminé...")
                break
        nbCoup += 1

        hint = input("L'entier a deviné est-il : " + str(r) + " ?\nSi j'ai deviné, répondez 'gagné', sinon, répondez '+' si c'est trop petit ou '-' si c'est trop grand : ")
        while not hint in l:
            hint = input("L'entier a deviné est-il : " + str(r) + " ?\nSi j'ai deviné, répondez 'gagné', sinon, répondez 'trop petit' ou 'trop grand' : ")
        if hint == "+":
            try:
                tree = get_right_son(tree)
            except AssertionError:
                print("N'aurais-tu pas triché par hasard ? Le jeu est terminé...")
                break
        elif hint == "-":
            try:
                tree = get_left_son(tree)
            except AssertionError:
                print("N'aurais-tu pas triché par hasard ? Le jeu est terminé...")
                break
        elif hint == "gagné":
            print("J'ai gagné ! J'ai deviné en", nbCoup, "coups.")
        if r == reponse and hint != "gagné":
            print("N'aurais-tu pas triché par hasard ? Le jeu est terminé...")
            break

# Tests sur les arbres binaires 
def testArbreBinaire (tree):
    imprimer(tree)
    print("")
    print("Taille    : %d" % (taille (tree)))
    print("Hauteur   : %d" % (hauteur (tree)))
    print("nbFeuilles: %d" % (nbFeuilles (tree)))

# Tests sur les arbres binaires de recherche 
def testABR (tree):
    imprimer(tree)
    print("")
    print("Taille    : %d" % (taille (tree)))
    print("Hauteur   : %d" % (hauteur (tree)))
    print("nbFeuilles: %d" % (nbFeuilles (tree)))
    print("Valeurs présentes dans l'arbre : ")
    for i in range(1,10+1):
        if appartient(i,tree): 
            print("%d " % i)
    print("")

# Programme principal 
if __name__ == "__main__":

    testArbreBinaire(arbre1())
    testArbreBinaire(arbre2())
    testArbreBinaire(arbre3())

    print("\n\nQuestion 5.3.6 :")
    for i in range(1,3+1):
        cpt = 0
        a = "abr{}()".format(i)
        a = eval(a)
        appartient(0, a)
        print("Le nombre de comparaisons de l'abr %d est %d pour une recherche infructueuse de 0." % (i, cpt))

    print("\n\nQuestion 5.2.3.7\n")
    t1_start = time.process_time()
    for i in range(0,15+1):
        print("Le nombre d'arbres à %d noeuds est %d" % (i,nbArbres(i)))
    t1_stop = time.process_time()
    print("\n\n")
        
    t2_start = time.process_time()
    for i in range(0,15+1):
        print("Le nombre d'arbres à %d noeuds est %d" % (i,nbArbresEfficace(i)))
    t2_stop = time.process_time()
    print("\n")
    
    print('Temps pour nbArbres:', t1_stop - t1_start)
    print('Temps pour nbArbresEfficace:', t2_stop - t2_start)
    
    testABR(abr1())
    testABR(abr2())
    testABR(abr3())

    print("Arbre mysterieux entre 12 et 24:");
    imprimer (construitArbreEntierMysterieux(12,24))
    print("\n\n")
    jouer(100);
