=========================
:mod:`test` module
=========================

.. automodule:: test
   :members:

Arbres Binaires
---------------

.. _fig:arbre1:
.. figure:: images/arbre1.png
   :align: center
   :width: 50%
   :alt: arbre 1

.. _fig:arbre2:
.. figure:: images/arbre2.png
   :align: center
   :width: 50%
   :alt: arbre 2

.. _fig:arbre3:
.. figure:: images/arbre3.png
   :align: center
   :width: 50%
   :alt: arbre 3

Arbres Binaires de Recherche
----------------------------

.. _fig:abr1:
.. figure:: images/abr1.png
   :align: center
   :width: 50%
   :alt: Arbre Binaire de Recherche 1
		  
.. _fig:abr2:
.. figure:: images/abr2.png
   :align: center
   :width: 50%
   :alt: Arbre Binaire de Recherche 2

.. _fig:abr3:
.. figure:: images/abr3.png
   :align: center
   :width: 50%
   :alt: Arbre Binaire de Recherche 3

.. _fig:abr_myst:
.. figure:: images/abr_myst.png
   :align: center
   :width: 50%
   :alt: Arbre Binaire de Recherche mystérieux de 12 à 24

