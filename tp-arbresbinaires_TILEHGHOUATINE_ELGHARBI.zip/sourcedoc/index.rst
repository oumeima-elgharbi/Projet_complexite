-----------------
tp-arbresbinaires
-----------------

~~~~~~~~~~
Etat du TP
~~~~~~~~~~

Nous avons fini le TP.

~~~~~~~~~~~~~~~~~~~~~~
Réponses aux questions
~~~~~~~~~~~~~~~~~~~~~~

~~~~~~~~~~~~~~~~~~~~~~~~
Décomptes sur les arbres
~~~~~~~~~~~~~~~~~~~~~~~~

Question 5.3.2.5
----------------
Réponse : On constate lors de l'impression du nombres d'arbres pour n >= 15 cela prend beaucoup de temps de calcul.

Le nombre d'arbres à 16 noeuds est 35357670
Le nombre d'arbres à 17 noeuds est 129644790
Le nombre d'arbres à 18 noeuds est 477638700
Le nombre d'arbres à 19 noeuds est 1767263190

Question 5.2.3.7
----------------
Réponse : On constate que l'affiche se fait très rapidement en comparaison à la fonction nbArbres récursive !  
Nous avons calculé à l'aide de la méthode process_time() le temps de calcul pour les deux fonctions dans test.py : la différence est énorme. 

~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Arbres binaires de recherche
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Question 5.3.2
--------------
Réponse : Pour vérifier que ce sont bien des arbres de recherche, on utilise la procédure imprimer() qui doit imprimer les valeurs de l'arbre dans l'ordre croissant. 
Nous avons choisi d'écrire une procédure imprimer() qui affiche de manière infixée mais différente de la procédure du CM car notre fonction était plus simple à concevoir et à écrire, et elle imprime aussi en écriture infixée les valeurs de l'arbre.


Question 5.3.6
--------------
Q : Sur lequel des trois arbres donnés en exemple y a-t-il le moins de comparaisons pour la recherche de 0 ? Pourquoi ?

Réponse : C'est pour abr3  que l'on a le moins de comparaisons pour la recherche infructueuse en 0, car pour abr3 la valeur 1 est le noeud gauche de la racine, donc on trouve vite que 0 n'est pas présent dans l'ABR.

Comme dans le test que nous avons réalisé dans test.py :
nombre de comparaisons de abr1 pour 0 = 8
nombre de comparaisons de abr2 pour 0 = 8
nombre de comparaisons de abr3 pour 0 = 4

Question 5.3.7
--------------
Q : Où se trouvent respectivement l’élément minimal et maximal d’un arbre binaire de recherche ?

Réponse : L'élément minimal se trouve dans le noeud le plus à gauche de l'ABR et l'élément maximal sur le noeud le plus à droite.


.. toctree::
   :maxdepth: 1

   test
   tree




